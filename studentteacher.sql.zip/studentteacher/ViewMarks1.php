<?php require_once("db.php"); ?>
<?php require_once("sessions.php"); ?>
<?php require_once("function1.php"); ?>
<?php 

confirm_login();

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<link rel="stylesheet" href="css/adminstyles.css">
<style>
	.fieldinfo{
		color: rgb(251,174,44);
		font-family: Bitter,Georgia,"Times New Roman",Times,seriff;
		font-size: 1.2em;
	}
</style>
</head>
<body>
<div class="container-fluid">
<div class="col-sm-2">
		<br>
		<br>
		<ul id="one" class="nav nav-pills nav-stacked">
	    <li><a href="rand1.php">
	    	<span class="glyphicon glyphicon-th"></span>&nbsp;&nbsp;Dashboard</a></li>
		
		
		<li class="active"><a href="ViewMarks.php">
<span class="glyphicon glyphicon-bookmark"></span>&nbsp;&nbsp;View Marks</a></li>
<li><a href="logout1.php">
<span class="glyphicon glyphicon-log-out"></span>&nbsp;Logout</a></li>
</ul>
	</div>

	<div class="col-sm-10">
		<h1>Marks Obtained By Students in Their Respective Subjects</h1>
		<?php echo message();
		echo successmessage(); ?>
		<div>
		</div>
		<div class="table-responsive">
			<table class="table table-striped table-hover">
				<tr>
					<th>Sr No.</th>
					<th>Roll No.</th>
					<th>Subject</th>
					<th>Marks</th>
				</tr>
				<?php
				global $connection;
				

                global $connection;
                $rollnumber=$_SESSION["rollno"];
                $viewquery="select * from marks where rollno='$rollnumber' order by sname desc";
                $execute=mysqli_query($connection,$viewquery);
                $srno=0;
                while($datarows=mysqli_fetch_array($execute)){
                	
                	$rollno=$datarows["rollno"];
                	$marks=$datarows["marks"];
                	$sname=$datarows["sname"];
                	$cname=$datarows["cname"];
                	$srno++;
                
?>
<tr>
	<td><?php echo $srno ?></td>
	<td><?php echo $rollno ?></td>
	<td><?php echo $sname; ?></td>
	<td><?php 
	if($marks==0)
		echo "0/Not Yet Checked";
	else
		echo $marks; ?></td>




</tr>
<?php } ?>
			</table>
		</div>
	</div>


</div>
</div>
<div id="Footer">
	<hr><p>Theme by| Pranjal Pandey | &copy:2016-2020 ---All Rights Reserved.</p>
	<a style ="color:white; text-decoration;none; cursor:pointer; font-weight: bold" href="https://www.facebook.com/"></a>
</div>

<div style="height: 10px; background:#27aae1;"></div>
</body>
</html>