<?php require_once("db.php"); ?>
<?php require_once("sessions.php"); ?>
<?php require_once("functions.php"); ?>
<?php 

confirm_login();

?>
<?php
$connection=mysqli_connect('localhost','root','','studentteacher');
if(isset($_POST["Submit"])){
  echo "hello";
	$Title=mysqli_real_escape_string($connection,$_POST["Title"]);
	$Category=mysqli_real_escape_string($connection,$_POST["Category"]);
	$Post=mysqli_real_escape_string($connection,$_POST["Post"]);

	



if(empty($Title)){
	$_SESSION["ErrorMessage"]= "Title can't be empty";
	redirect_to("addnewpost.php");
}
else{
	global $connection;
  $rollfromurl=$_GET['Roll'];
  $query1="select sid from marks where rollno='$rollfromurl'";

	

	$query="insert into marks values()  ";
  
	$execute=mysqli_query($connection,$query);

	if($execute)
	{
		$_SESSION["SuccessMessage"]="Post updated Succesfully";
		redirect_to("dashboard.php");
	}else{
    die(mysqli_error($connection));
		$_SESSION["ErrorMessage"]="Something went wrong";
		redirect_to("dashboard.php");
    echo $Title;
	}
}
}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.2.1.min.js"></script>
  <script src="js/ckeditor.js"></script>
<script src="js/bootstrap.min.js"></script>

<link rel="stylesheet" href="css/adminstyles.css">
<style>
	.fieldinfo{
		color: rgb(251,174,44);
		font-family: Bitter,Georgia,"Times New Roman",Times,seriff;
		font-size: 1.2em;
	}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row">
	<div class="col-sm-2">
		<h1></h1>
		<ul id="one" class="nav nav-pills nav-stacked">

	    <li><a href="dashboard.php">
	    	<span class="glyphicon glyphicon-th"></span>&nbsp;Dashboard</a></li>
		<li class="active"><a href="addnewpost.php">
			<span class="glyphicon glyphicon-list-alt"></span>&nbsp;Add New Content</a></li>
		<li><a href="categories.php">
			<span class="glyphicon glyphicon-tags"></span>&nbsp;Categories</a></li>
		<li><a href="#">
		<span class="glyphicon glyphicon-user"></span>&nbsp;Manage Admins</a></li>
		<li><a href="#">
		<span class="glyphicon glyphicon-comment"></span>&nbsp;Comments</a></li>
		<li><a href="#">
		<span class="glyphicon glyphicon-equalizer"></span>&nbsp;Live Blog</a></li>
		<li><a href="#">
		<span class="glyphicon glyphicon-log-out"></span>&nbsp;Logout</a></li>
	    </ul>

	</div>
	<div class="col-sm-10">
		<h1>Update Post</h1>
		<?php echo message();
		echo successmessage(); ?>
		<div>
		 <?/*php 
			$rollfromurl=$_GET['Roll'];
			$connection;
            
            $query="select * from admin_panel where rollno='$rollfromurl'";
            $execute=mysqli_query($connection,$query);
            while($datarows=mysqli_fetch_array($execute)){
            	$Titletobeupdated=$datarows['title'];
            	$Categorytobeupdated=$datarows['category'];
            	$Imagetobeupdated=$datarows['image'];
            	$Posttobeupdated=$datarows['post'];

            }


			*/?> 
       <form action="editpost.php?Edit=<?php echo $searchqueryparameter;?>" method="get" enctype="multipart/form-data">

       	<fieldset>
       		<div class="form-group">
       	<label for="title"><span class="fieldinfo">Course Name:</span></label>
       	  <select class="form-control" id="COURSESELECT" name="Cname">
          <?php
               $rollfromurl=$_GET['Roll'];      
                global $connection;
                $viewquery="select cname from subject s,marks m where s.sid=m.sid and m.rollno='$rollfromurl' ";
                $execute=mysqli_query($connection,$viewquery);
                
                while($datarows=mysqli_fetch_array($execute)){
                 
                    $CName=$datarows["cname"];
               ?>
               <option><?php echo $CName; ?></option>
               <?php } ?>



        </select>
       	</div>
       	<div class="form-group">
       	<label for="categoryselect"><span class="fieldinfo">Subject Name:</span></label>
       	<select class="form-control" id="categoryselect" name="Sname">
       		<?php
                $rollfromurl=$_GET['Roll'];      
                global $connection;
                $viewquery="SELECT sname from subject where cname in (SELECT s.cname from marks m,subject s where s.sid=m.sid and m.rollno='$rollfromurl') ";
                $execute=mysqli_query($connection,$viewquery);
                
                while($datarows=mysqli_fetch_array($execute)){
                 
                    $SName=$datarows["sname"];
               ?>
               <option><?php echo $SName; ?></option>
               <?php } ?>



       	</select>
       </div>
       <div class="form-group">
       		
       	<label for="imageselect"><span class="fieldinfo">Enter The Marks:</span></label>
       	<input type="Number" class="form-control" name="Image" id="imageselect">
       </div>
       	<br>


       <br>
       	       	<input class ="btn btn-success btn-block" type="submit" name="Submit" value="Add The Marks">
       	</fieldset>
       	<br>
       </form>			
		</div>
	</div>


</div>
</div>
<div id="Footer">
	<hr><p>Theme by| Pranjal Pandey | &copy:2016-2020 ---All Rights Reserved.</p>
	<a style ="color:white; text-decoration;none; cursor:pointer; font-weight: bold" href="https://www.facebook.com/"></a>
</div>
<div style="height: 10px; background:#27aae1;"></div>
</body>
</html>