
<?php require_once("db.php"); ?>
<?php require_once("sessions.php"); ?>
<?php require_once("function1.php"); ?>
<?php 

confirm_login();

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<link rel="stylesheet" href="css/adminstyles.css">
</head>
<body>
	<div style="height: 10px; background: #27aae1;"></div>
	<nav class="navbar navbar-inverse role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse">
					<span class="sr-only">Toggle Navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			<a class="navbar-brand" href="Blog.php"><img style="margin-top: -12px" src="Images/images5.jpg" width=200; height=50; ></a>
			</div>
			<div class="collapse navbar-collapse" id="collapse">
<
<form action="https://www.google.com/" class="navbar-form navbar-right">
	<div class="form-group">
		<input type="text" class="form-control" placeholder="Search" name="Search">
    </div>
    <button class="btn btn-default" name="SearchButton">Go</button>
</form>
</div>
</div>
</nav>
<div class="Line" style="height:10px; background: #27aae1;margin-top: -20px;"></div>
<div class="container-fluid">
<div class="row">
	<div class="col-sm-2">
		<br>
		<br>
		<ul id="one" class="nav nav-pills nav-stacked">
	    <li class="active"><a href="rand1.php">
	    	<span class="glyphicon glyphicon-th"></span>&nbsp;&nbsp;Dashboard</a></li>
		<li><a href="ViewMarks1.php">
<span class="glyphicon glyphicon-bookmark"></span>&nbsp;&nbsp;View Marks</a></li>
<li><a href="logout1.php">
<span class="glyphicon glyphicon-log-out"></span>&nbsp;Logout</a></li>
</ul>
	</div>
	<div class="col-sm-10">
		<div><?php echo message();
		          echo successmessage(); ?></div>
		          <div class="container"></div>
		          <div class="panel panel-warning">
				<div class="panel-heading">
					<span class="glyphicon glyphicon-user" width=50; height=100;></span><h3>Teacher Dashboard</h3>
				
		</div>
		<?php $name=$_SESSION["rollno"] ?>
		<div class="panel-footer"><p style="font-size: 1.6em; color: green;">Nice to see you here <?php echo $name ?>!</div>
	</div>
	<div class="col-sm-3">
				  <div class="panel panel-danger">
				<div class="panel-heading">
					<div class="panel-title"><span class="glyphicon glyphicon-user" width=50; height=100;></span><h3>Total Courses</h3>
					<div class="panel-body">	<?php
		$connection;
		$querytotal="select count(*) from course";
		$executetotal=mysqli_query($connection,$querytotal);
		$rowstotal=mysqli_fetch_array($executetotal);
		$totaltotal=array_shift($rowstotal);
		
		?>
		<span class="pull-right">
        <?php echo $totaltotal;?>
</span>
				</div>
			</div>
		</div>
		<div class="panel-footer"><a href="course1.php">View Details</a></div>
	</div>
</div>
<div class="col-sm-3">
				  <div class="panel panel-success">
				<div class="panel-heading">
					<div class="panel-title"><span class="glyphicon glyphicon-comment" width=50; height=100;></span><h3>Total Subjects</h3>
					<div class="panel-body">	<?php
		$connection;
		$querytotal="select count(*) from subject";
		$executetotal=mysqli_query($connection,$querytotal);
		$rowstotal=mysqli_fetch_array($executetotal);
		$totaltotal=array_shift($rowstotal);
		//if($totaltotal>0){ 
		///?>
		<span class="pull-right">
        <?php echo $totaltotal;?>
</span>
<?//php } ?>
				</div>
			</div>
		</div>
		<div class="panel-footer"><a href="subject1.php">View Details</a></div>
	</div>
</div>
<div class="col-sm-3">
				  <div class="panel panel-info">
				<div class="panel-heading">
					<div class="panel-title"><span class="glyphicon glyphicon-bookmark" width=50; height=100;></span><h3>Total Students</h3>
					<div class="panel-body">	<?php
		$connection;
		
		$querytotal="select count(*) from student";
		$executetotal=mysqli_query($connection,$querytotal);
		$rowstotal=mysqli_fetch_array($executetotal);
		$totaltotal=array_shift($rowstotal);
		//if($totaltotal>0){ 
		//?>
		<span class="pull-right">
        <?php echo $totaltotal;?>
</span>
<?//php } ?>
				</div>
			</div>
		</div>
		<div class="panel-footer"><a href="studentlist2.php">View Details</a></div>
	</div>
</div>



				
		
         <br><br>
         <br><br>

<br><br>

</p>
</div>
</div>
</div>
</div>
</div>






<div id="Footer">
	<hr><p>Theme by| Pranjal Pandey | &copy:2016-2020 ---All Rights Reserved.</p>
	<a style ="color:white; text-decoration;none; cursor:pointer; font-weight: bold" href="https://www.facebook.com/"></a>
</div>
<div style="height: 10px; background:#27aae1;"></div>
</body>
</html>