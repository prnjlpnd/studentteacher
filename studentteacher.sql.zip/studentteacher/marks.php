<?php require_once("db.php"); ?>
<?php require_once("sessions.php"); ?>
<?php require_once("functions.php"); ?>
<?php 

confirm_login();

?>
<?php
$connection=mysqli_connect('localhost','root','','studentteacher');
if(isset($_POST["Submit"])){
		$Course=mysqli_real_escape_string($connection,$_POST["Course"]);
	$Title=mysqli_real_escape_string($connection,$_POST["Title"]);
	$Roll=mysqli_real_escape_string($connection,$_POST["Roll"]);
	$Marks=mysqli_real_escape_string($connection,$_POST["Marks"]);
echo $Title;
echo $CourseName;
	

	
if(empty($Title)||empty($Roll)||empty($Marks)){
	$_SESSION["ErrorMessage"]= " Field Name can't be empty";
	redirect_to("marks.php?Roll=$Roll&Sname=$Title&Cname=$Course");
}
if($Marks>100){

	$_SESSION["ErrorMessage"]= "MARKS CAN'T BE GREATER THAN 100!!";
	redirect_to("marks.php");
}
else{
	global $connection;
$TITLE=strtoupper($Title);



	$query="UPDATE marks SET marks='$Marks' where sname='$Title' and cname='$Course' and rollno='$Roll'";
	$execute=mysqli_query($connection,$query);
	if($execute)
	{
		$_SESSION["SuccessMessage"]="Marks added Succesfully";
		redirect_to("studentlist1.php");
	}else{
		echo $Title;
		echo $CourseName;
		$_SESSION["ErrorMessage"]="Some Error Occured";
		redirect_to("marks.php");
	}
}
}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
	<script src="js/ckeditor.js"></script>
<link rel="stylesheet" href="css/adminstyles.css">
<style>
	.fieldinfo{
		color: rgb(251,174,44);
		font-family: Bitter,Georgia,"Times New Roman",Times,seriff;
		font-size: 1.2em;
	}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row">
	<div class="col-sm-2">
		<br>
		<br>
		<ul id="one" class="nav nav-pills nav-stacked">
	    <li><a href="rand.php">
	    	<span class="glyphicon glyphicon-th"></span>&nbsp;&nbsp;Dashboard</a></li>
		<li><a href="addnewcourse.php">
			<span class="glyphicon glyphicon-list-alt"></span>&nbsp;&nbsp;Add New Course</a></li>
		<li><a href="addnewsubject.php">
			<span class="glyphicon glyphicon-tags"></span>&nbsp;&nbsp;Add new subject</a></li>
		<li><a href="addnewteacher.php">
		<span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;Add New Teacher</a></li>
		<li class="active"><a href="studentlist1.php">
		<span class="glyphicon glyphicon-comment"></span>&nbsp;&nbsp;Add Marks</a></li>
		
		<li><a href="ViewMarks.php">
<span class="glyphicon glyphicon-bookmark"></span>&nbsp;&nbsp;View Marks</a></li>
<li><a href="logout.php">
<span class="glyphicon glyphicon-log-out"></span>&nbsp;Logout</a></li>
</ul>
	</div>

	<div class="col-sm-10">
		<h1>Add The Marks</h1>
		<?php echo message();
		echo successmessage(); ?>
		<div>
       <form action="marks.php" method="post" enctype="multipart/form-data">

       	<fieldset>
       		<div class="form-group">
       	<label for="title"><span class="fieldinfo">Course Name:</span></label>
       	<select class="form-control" id="categoryselect" name="Course">
       		<?php
                global $connection;
               $CNAME=$_GET["Cname"];
               ?>
               <option><?php echo $CNAME; ?></option>
              


       	</select>
       	</div>
       		<div class="form-group">
       	<label for="title"><span class="fieldinfo">Subject Name:</span></label>
       	<select class="form-control" id="categoryselect" name="Title">
       		<?php
                global $connection;
               $SNAME=$_GET["Sname"];
               ?>
               <option><?php echo $SNAME; ?></option>
              


       	</select>
       	</div>
       	<div class="form-group">
       	<label for="Student"><span class="fieldinfo">Student Roll no.:</span></label>
       		<select class="form-control" id="categoryselect" name="Roll">
       		<?php
                global $connection;
               $rollnumber=$_GET['Roll'];
               
                
               ?>
               <option><?php echo $rollnumber; ?></option>
               <?php ?>



       	</select>
       	</div>
       	<div class="form-group">
       	<label for="Marks"><span class="fieldinfo">Student Marks:</span></label>
       	<input class="form-control"  type="number" name="Marks" id="title" placeholder="Marks Out Of 100">
       	</div>
       	<br><div>
       			
       </div>
      
       <br>
       	       	<input class ="btn btn-success btn-block" type="submit" name="Submit" value="Add Marks">
       	</fieldset>
       	<br>

       </form>			
		</div>
		
	</div>		
</div>
</div>


<div id="Footer">
	<hr><p>Theme by| Pranjal Pandey | &copy:2016-2020 ---All Rights Reserved.</p>
	<a style ="color:white; text-decoration;none; cursor:pointer; font-weight: bold" href="https://www.facebook.com/"></a>
</div>
<div style="height: 10px; background:#27aae1;"></div>
</body>
</html>