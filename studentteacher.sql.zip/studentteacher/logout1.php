<?php require_once("function1.php"); ?>
<?php require_once("sessions.php"); ?>
<?php

$_SESSION["rollno"]=null;
session_destroy();
redirect_to("Welcome.php");


 ?>