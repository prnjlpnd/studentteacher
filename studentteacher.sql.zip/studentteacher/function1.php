<?php require_once("db.php"); ?>
<?php require_once("sessions.php"); ?>
<?php
function redirect_to($new_location){
	header("Location:".$new_location);
	exit;
}
function login_attempt($rollno){
global $connection;
$query="select * from student where rollno='$rollno'";
$execute=mysqli_query($connection,$query);
if($admin=mysqli_fetch_assoc($execute))
{
	return $admin;
}
else{
	return null;
}
}
function login(){
	if(isset($_SESSION["rollno"])){
		return true;
	}
}
function confirm_login(){
	if(!login()){
		$_SESSION["ErrorMessage"]="Login Required";
		redirect_to("loginstudent.php");
	}
}

 ?>