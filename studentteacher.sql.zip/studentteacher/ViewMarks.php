<?php require_once("db.php"); ?>
<?php require_once("sessions.php"); ?>
<?php require_once("functions.php"); ?>
<?php 

confirm_login();

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<link rel="stylesheet" href="css/adminstyles.css">
<style>
	.fieldinfo{
		color: rgb(251,174,44);
		font-family: Bitter,Georgia,"Times New Roman",Times,seriff;
		font-size: 1.2em;
	}
</style>
</head>
<body>

<div class="container-fluid">
<div class="row">
	<div class="col-sm-2">
		<h1></h1>
		<ul id="one" class="nav nav-pills nav-stacked">
	    <li class="active"><a href="rand.php">
	    	<span class="glyphicon glyphicon-th"></span>&nbsp;&nbsp;Dashboard</a></li>
		<li><a href="addnewcourse.php">
			<span class="glyphicon glyphicon-list-alt"></span>&nbsp;&nbsp;Add New Course</a></li>
		<li><a href="addnewsubject.php">
			<span class="glyphicon glyphicon-tags"></span>&nbsp;&nbsp;Add new subject</a></li>
		<li><a href="addnewteacher.php">
		<span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;Add New Teacher</a></li>
		<li><a href="studentlist1.php">
		<span class="glyphicon glyphicon-comment"></span>&nbsp;&nbsp;Add Marks</a></li>
		
		<li><a href="ViewMarks.php">
<span class="glyphicon glyphicon-bookmark"></span>&nbsp;&nbsp;View Marks</a></li>
<li><a href="enroll.php">
<span class="glyphicon glyphicon-log-in"></span>&nbsp;&nbsp;Enroll A Student</a></li>
<li><a href="logout.php">
<span class="glyphicon glyphicon-log-out"></span>&nbsp;Logout</a></li>
</ul>
	</div>

	<div class="col-sm-10">
		<h1>List Of All Students</h1>
		<?php echo message();
		echo successmessage(); ?>
		<div>
		</div>
		<div class="table-responsive">
			<table class="table table-striped table-hover">
				<tr>
					<th>Sr No.</th>
					<th>Roll no.</th>
					<th>Subject Name</th>
					<th>Course Name</th>
					<th>Marks</th>
					
					
				</tr>
				<?php
                global $connection;
                
                $viewquery="select * from marks order by rollno desc";
                $execute=mysqli_query($connection,$viewquery);
                $srno=0;
                while($datarows=mysqli_fetch_array($execute)){
                	
                	$rollno=$datarows["rollno"];
                	$sname=$datarows["sname"];
                	$cname=$datarows["cname"];
                	$marks=$datarows["marks"];

                    

                	$srno++;
                
?>
<tr>
	<td><?php echo $srno; ?></td>
	<td><?php echo $rollno; ?></td>
	<td><?php echo $sname; ?></td>
	<td><?php echo $cname; ?></td>
	<td><?php if($marks==null){
		echo "0/NOT ASSIGNED";
	}
else
	echo $marks; ?></td>
    



</tr>
<?php } ?>
			</table>
		</div>
	</div>


</div>
</div>
<div id="Footer">
	<hr><p>Theme by| Pranjal Pandey | &copy:2016-2020 ---All Rights Reserved.</p>
	<a style ="color:white; text-decoration;none; cursor:pointer; font-weight: bold" href="https://www.facebook.com/"></a>
</div>

<div style="height: 10px; background:#27aae1;"></div>
</body>
</html>