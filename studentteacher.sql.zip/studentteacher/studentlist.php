<?php require_once("db.php"); ?>
<?php require_once("sessions.php"); ?>
<?php require_once("functions.php"); ?>
<?php 

confirm_login();

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<link rel="stylesheet" href="css/adminstyles.css">
<style>
	.fieldinfo{
		color: rgb(251,174,44);
		font-family: Bitter,Georgia,"Times New Roman",Times,seriff;
		font-size: 1.2em;
	}
</style>
</head>
<body>
<div class="container-fluid">


	<div class="col-sm-10">
		<h1>List Of All Students</h1>
		<?php echo message();
		echo successmessage(); ?>
		<div>
		</div>
		<div class="table-responsive">
			<table class="table table-striped table-hover">
				<tr>
					<th>Sr No.</th>
					<th>Roll no.</th>
					
				</tr>
				<?php
                global $connection;
                
                $viewquery="select * from student order by rollno desc";
                $execute=mysqli_query($connection,$viewquery);
                $srno=0;
                while($datarows=mysqli_fetch_array($execute)){
                	
                	$rollno=$datarows["rollno"];
                	$srno++;
                
?>
<tr>
	<td><?php echo $srno; ?></td>
	<td><?php echo $rollno; ?></td>




</tr>
<?php } ?>
			</table>
		</div>
	</div>


</div>
</div>
<div id="Footer">
	<hr><p>Theme by| Pranjal Pandey | &copy:2016-2020 ---All Rights Reserved.</p>
	<a style ="color:white; text-decoration;none; cursor:pointer; font-weight: bold" href="https://www.facebook.com/"></a>
</div>

<div style="height: 10px; background:#27aae1;"></div>
</body>
</html>