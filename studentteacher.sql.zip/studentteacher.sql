-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 18, 2019 at 05:45 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentteacher`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `cname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`cname`) VALUES
('15CS01'),
('15CS02'),
('15CS03'),
('15CS04'),
('15CS05'),
('15CS06'),
('15CS07'),
('15CS08'),
('15CS09'),
('15CS105');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `sname` varchar(100) NOT NULL,
  `rollno` varchar(20) NOT NULL,
  `marks` int(3) DEFAULT NULL,
  `cname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`sname`, `rollno`, `marks`, `cname`) VALUES
('ADVANCED AI', '1BI16CS105', NULL, '15CS105'),
('ADVANCED ML', '1BI16CS105', NULL, '15CS105'),
('AI', '1BI16CS105', NULL, '15CS105'),
('AJAVA', '1BI16CS105', NULL, '15CS105'),
('COMPUTER NETWORK', '1BI16CS105', NULL, '15CS105'),
('HYDRAULIC DESIGN', '1BI16CS105', NULL, '15CS105'),
('NEURAL NETWORK', '1BI16CS105', NULL, '15CS105'),
('NLP', '1BI16CS105', NULL, '15CS105'),
('SOFTWARE ENGINEERING', '1BI16CS105', NULL, '15CS105'),
('WORK SHOP', '1BI16CS105', NULL, '15CS105'),
('ADE', '1BI16CS113', NULL, '15CS04'),
('ANDROID DEV', '1BI16CS113', NULL, '15CS04'),
('DSA', '1BI16CS113', NULL, '15CS04'),
('NODE.JS', '1BI16CS113', NULL, '15CS04'),
('ANALOG ECE', '1BI16CS113', NULL, '15CS08'),
('CAED', '1BI16CS113', NULL, '15CS08'),
('CONVENTIONAL RESOURCES', '1BI16CS113', NULL, '15CS08'),
('ELEMNTS OF MECHANICAL ENGINNERING', '1BI16CS113', NULL, '15CS08'),
('ENGINES', '1BI16CS113', NULL, '15CS08');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `rollno` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`rollno`) VALUES
('1bi16cs102'),
('1BI16CS103'),
('1BI16CS104'),
('1BI16CS105'),
('1BI16CS113');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `sid` int(10) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `cname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sid`, `sname`, `cname`) VALUES
(18, 'ADE', '15CS04'),
(21, 'DSA', '15CS04'),
(23, 'MATHS', '15CS01'),
(24, 'DBMS', '15CS01'),
(25, 'UNIX', '15CS01'),
(26, 'CHEMISTRY', '15CS01'),
(27, 'ELECTRONICS', '15CS01'),
(28, 'ML', '15CS02'),
(29, 'AI', '15CS105'),
(30, 'NLP', '15CS105'),
(31, 'NEURAL NETWORK', '15CS105'),
(32, 'ADVANCED AI', '15CS105'),
(33, 'ADVANCED ML', '15CS105'),
(34, 'JAVA', '15CS05'),
(35, 'AJAVA', '15CS105'),
(36, 'COMPUTER NETWORK', '15CS105'),
(37, 'SOFTWARE ENGINEERING', '15CS105'),
(38, 'ME', '15CS05'),
(39, 'OS', '15CS05'),
(40, 'SS', '15CS05'),
(41, 'COMPUTER GRAPHICS', '15CS05'),
(42, 'BASIC ALGEBRA', '15CS06'),
(43, 'PYTHON', '15CS06'),
(44, 'HTML', '15CS06'),
(45, 'CSS', '15CS06'),
(46, 'PHP', '15CS06'),
(47, 'JAVASCRIPT', '15CS06'),
(48, 'COMPUTER ORGANISATION', '15CS06'),
(49, 'MICROPROCESSORS', '15CS07'),
(50, 'MICROCONTROLLERS', '15CS07'),
(51, 'ANALOG AND DIGITAL ELECTRONICS', '15CS07'),
(52, 'SIGNALLING SYSTEMS', '15CS07'),
(53, 'ELEMENTS OF CIVIL ENGINEERING', '15CS07'),
(54, 'ELEMNTS OF MECHANICAL ENGINNERING', '15CS08'),
(55, 'CAED', '15CS08'),
(56, 'WORK SHOP', '15CS105'),
(57, 'HYDRAULIC DESIGN', '15CS105'),
(58, 'ENGINES', '15CS08'),
(59, 'CONVENTIONAL RESOURCES', '15CS08'),
(60, 'SOFTWARE DESIGN', '15CS09'),
(61, 'DISCRETE MATHEMATICS', '15CS09'),
(62, 'LINEAR ALGEBRA', '15CS09'),
(63, 'OPERATIONAL RESEARCH', '15CS09'),
(64, 'ROBOTICS', '15CS02'),
(65, 'PUBLIC SPEAKING', '15CS02'),
(66, 'DRAMATICS', '15CS02'),
(67, 'LAW AND ETHICS', '15CS02'),
(68, 'CONSTITUTION OF INDIA', '15CS02'),
(69, 'REACT JS', '15CS02'),
(70, 'POETRY', '15CS02'),
(71, 'HUMANITY', '15CS02'),
(75, 'ANALOG ECE', '15CS08'),
(76, 'NODE.JS', '15CS04'),
(77, 'ANDROID DEV', '15CS04');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `name`, `password`) VALUES
(1, 'first teacher', '1234'),
(3, 'KR SUNEETHA', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`cname`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`rollno`,`cname`,`sname`),
  ADD KEY `fk70` (`cname`),
  ADD KEY `fk71` (`sname`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`rollno`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`sid`),
  ADD UNIQUE KEY `sname` (`sname`),
  ADD KEY `fk7` (`cname`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `sid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `fk70` FOREIGN KEY (`cname`) REFERENCES `course` (`cname`),
  ADD CONSTRAINT `fk71` FOREIGN KEY (`sname`) REFERENCES `subject` (`sname`),
  ADD CONSTRAINT `fk72` FOREIGN KEY (`rollno`) REFERENCES `student` (`rollno`);

--
-- Constraints for table `subject`
--
ALTER TABLE `subject`
  ADD CONSTRAINT `fk7` FOREIGN KEY (`cname`) REFERENCES `course` (`cname`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
